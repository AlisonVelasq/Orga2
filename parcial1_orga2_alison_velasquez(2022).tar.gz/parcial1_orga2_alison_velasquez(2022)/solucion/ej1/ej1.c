#include "ej1.h"

char** agrupar_c(msg_t* msgArr, size_t msgArr_len){
}
