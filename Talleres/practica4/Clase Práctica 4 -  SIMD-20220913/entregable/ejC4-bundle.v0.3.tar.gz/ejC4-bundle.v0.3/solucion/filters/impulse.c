#include<stdint.h>

int FILTER_TAP_NUM_IMPULSE = 8;

int16_t COEFS_IMPULSE[] = {
  32767,
  0,
  0,
  0,
  0,
  0,
  0,
  0
};
